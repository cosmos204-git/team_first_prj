package kr.co.sist.stu.dto;

public class SearchCourseDTO {

}
