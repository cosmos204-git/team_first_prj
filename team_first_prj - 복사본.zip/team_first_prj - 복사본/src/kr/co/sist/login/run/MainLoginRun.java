package kr.co.sist.login.run;

import kr.co.sist.login.view.MainLoginDesign;

public class MainLoginRun {

	public static void main(String[] args) {

		new MainLoginDesign();
		
	}

}
